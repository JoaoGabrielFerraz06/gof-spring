# Explorando Padrões de Projeto na Prática com Java

Projeto do desafio **Design Patterns com Java: Dos Clássicos (GoF) ao Spring Framework** (DIO / CI&T).

## Padrões implementados

**Java puro** (`com.joao.gof.puro`, execute `PadroesPuros.main`)
- **Singleton**: três variações (Lazy, Eager e Lazy Holder).
- **Strategy**: `Robo` com comportamentos Normal, Defensivo e Agressivo, trocados em tempo de execução.
- **Facade**: `Facade.migrarCliente` esconde os subsistemas `CepApi` e `CrmService`.

**Spring Boot** (`com.joao.gof.spring`)
- API REST de clientes (CRUD) com Spring Data JPA + H2.
- **Singleton**: beans do Spring (escopo padrão).
- **Strategy**: interface `ClienteService` com implementação injetada.
- **Facade**: `ClienteServiceImpl` unifica repositórios e a consulta de CEP no ViaCEP.

## Como executar
```
mvn spring-boot:run
```
Swagger: http://localhost:8080/swagger-ui.html

Exemplo:
```
POST /clientes
{ "nome": "João", "endereco": { "cep": "18200000" } }
```

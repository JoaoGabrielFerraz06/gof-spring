package com.joao.gof.puro.singleton;

/** Singleton apressado: a instância é criada ao carregar a classe. */
public class SingletonEager {
    private static final SingletonEager INSTANCIA = new SingletonEager();

    private SingletonEager() {}

    public static SingletonEager getInstancia() {
        return INSTANCIA;
    }
}

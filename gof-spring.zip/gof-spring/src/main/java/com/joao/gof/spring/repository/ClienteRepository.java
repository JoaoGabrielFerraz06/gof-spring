package com.joao.gof.spring.repository;

import com.joao.gof.spring.model.Cliente;
import org.springframework.data.repository.CrudRepository;

public interface ClienteRepository extends CrudRepository<Cliente, Long> {}

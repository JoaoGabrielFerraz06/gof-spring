package com.joao.gof.puro.strategy;

public interface Comportamento {
    void mover();
}

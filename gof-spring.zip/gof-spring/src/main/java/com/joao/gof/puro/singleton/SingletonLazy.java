package com.joao.gof.puro.singleton;

/** Singleton preguiçoso: a instância só é criada no primeiro uso. */
public class SingletonLazy {
    private static SingletonLazy instancia;

    private SingletonLazy() {}

    public static synchronized SingletonLazy getInstancia() {
        if (instancia == null) {
            instancia = new SingletonLazy();
        }
        return instancia;
    }
}

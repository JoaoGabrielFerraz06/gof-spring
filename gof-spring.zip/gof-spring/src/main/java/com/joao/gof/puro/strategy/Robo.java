package com.joao.gof.puro.strategy;

/** Contexto do Strategy: delega o movimento ao comportamento atual. */
public class Robo {
    private Comportamento comportamento = new ComportamentoNormal();

    public void setComportamento(Comportamento comportamento) {
        this.comportamento = comportamento;
    }

    public void mover() {
        comportamento.mover();
    }
}

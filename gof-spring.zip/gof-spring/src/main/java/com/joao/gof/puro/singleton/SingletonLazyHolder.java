package com.joao.gof.puro.singleton;

/** Lazy Holder: preguiçoso e thread-safe sem usar synchronized. */
public class SingletonLazyHolder {
    private static class Holder {
        private static final SingletonLazyHolder INSTANCIA = new SingletonLazyHolder();
    }

    private SingletonLazyHolder() {}

    public static SingletonLazyHolder getInstancia() {
        return Holder.INSTANCIA;
    }
}

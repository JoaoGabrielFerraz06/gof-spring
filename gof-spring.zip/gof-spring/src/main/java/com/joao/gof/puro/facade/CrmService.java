package com.joao.gof.puro.facade;

/** Subsistema 2: simula um sistema de CRM. */
public class CrmService {
    private CrmService() {}

    public static void gravarCliente(String nome, String cep, String cidade, String estado) {
        System.out.println("Cliente salvo no CRM:");
        System.out.println(nome + " | CEP " + cep + " | " + cidade + "/" + estado);
    }
}

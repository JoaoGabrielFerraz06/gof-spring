package com.joao.gof.spring.service;

import com.joao.gof.spring.model.Cliente;
import com.joao.gof.spring.model.Endereco;
import com.joao.gof.spring.repository.ClienteRepository;
import com.joao.gof.spring.repository.EnderecoRepository;
import org.springframework.stereotype.Service;

import java.util.NoSuchElementException;

/** Singleton (bean do Spring) + Facade sobre repositórios e ViaCEP. */
@Service
public class ClienteServiceImpl implements ClienteService {
    private final ClienteRepository clienteRepository;
    private final EnderecoRepository enderecoRepository;
    private final ViaCepService viaCepService;

    public ClienteServiceImpl(ClienteRepository c, EnderecoRepository e, ViaCepService v) {
        this.clienteRepository = c;
        this.enderecoRepository = e;
        this.viaCepService = v;
    }

    @Override
    public Iterable<Cliente> buscarTodos() {
        return clienteRepository.findAll();
    }

    @Override
    public Cliente buscarPorId(Long id) {
        return clienteRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Cliente não encontrado: " + id));
    }

    @Override
    public void inserir(Cliente cliente) {
        salvarComCep(cliente);
    }

    @Override
    public void atualizar(Long id, Cliente cliente) {
        buscarPorId(id);
        cliente.setId(id);
        salvarComCep(cliente);
    }

    @Override
    public void deletar(Long id) {
        clienteRepository.deleteById(id);
    }

    private void salvarComCep(Cliente cliente) {
        String cep = cliente.getEndereco().getCep();
        Endereco endereco = enderecoRepository.findById(cep)
                .orElseGet(() -> enderecoRepository.save(viaCepService.consultarCep(cep)));
        cliente.setEndereco(endereco);
        clienteRepository.save(cliente);
    }
}

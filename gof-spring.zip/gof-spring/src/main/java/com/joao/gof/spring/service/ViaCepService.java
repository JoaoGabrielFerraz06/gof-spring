package com.joao.gof.spring.service;

import com.joao.gof.spring.model.Endereco;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/** Integração com a API pública ViaCEP. */
@Component
public class ViaCepService {
    private final RestClient client = RestClient.create("https://viacep.com.br/ws");

    public Endereco consultarCep(String cep) {
        Endereco e = client.get().uri("/{cep}/json/", cep).retrieve().body(Endereco.class);
        if (e == null || e.getLocalidade() == null) {
            throw new IllegalArgumentException("CEP inválido: " + cep);
        }
        e.setCep(cep);
        return e;
    }
}

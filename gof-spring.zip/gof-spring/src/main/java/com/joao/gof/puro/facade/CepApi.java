package com.joao.gof.puro.facade;

/** Subsistema 1 (Singleton): simula uma consulta de CEP. */
public class CepApi {
    private static final CepApi INSTANCIA = new CepApi();

    private CepApi() {}

    public static CepApi getInstancia() {
        return INSTANCIA;
    }

    public String recuperarCidade(String cep) {
        return "Itapetininga";
    }

    public String recuperarEstado(String cep) {
        return "SP";
    }
}

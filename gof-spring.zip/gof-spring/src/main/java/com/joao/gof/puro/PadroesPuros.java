package com.joao.gof.puro;

import com.joao.gof.puro.facade.Facade;
import com.joao.gof.puro.singleton.*;
import com.joao.gof.puro.strategy.*;

/** Demonstra os três padrões em Java puro. Execute o método main. */
public class PadroesPuros {
    public static void main(String[] args) {
        System.out.println("=== Singleton ===");
        System.out.println(SingletonLazy.getInstancia() == SingletonLazy.getInstancia());
        System.out.println(SingletonEager.getInstancia() == SingletonEager.getInstancia());
        System.out.println(SingletonLazyHolder.getInstancia() == SingletonLazyHolder.getInstancia());

        System.out.println("=== Strategy ===");
        Robo robo = new Robo();
        robo.mover();
        robo.setComportamento(new ComportamentoDefensivo());
        robo.mover();
        robo.setComportamento(new ComportamentoAgressivo());
        robo.mover();

        System.out.println("=== Facade ===");
        new Facade().migrarCliente("João", "18200000");
    }
}

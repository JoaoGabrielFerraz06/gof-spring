package com.joao.gof.spring.repository;

import com.joao.gof.spring.model.Endereco;
import org.springframework.data.repository.CrudRepository;

public interface EnderecoRepository extends CrudRepository<Endereco, String> {}
